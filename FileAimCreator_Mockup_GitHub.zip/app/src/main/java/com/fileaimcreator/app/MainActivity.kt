
package com.fileaimcreator.app

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : Activity() {

    private lateinit var ui: CreatorView
    private val prefs by lazy { getSharedPreferences("fac", MODE_PRIVATE) }
    private var pendingContent = ""

    private val openFile = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        ui.sourceName = uri?.lastPathSegment ?: "Chưa chọn file"
        ui.invalidate()
    }

    private val saveFile = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(pendingContent.toByteArray()) }
            ui.page = 3
            ui.invalidate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5,8,18)
        window.navigationBarColor = Color.rgb(5,8,18)
        ui = CreatorView(this)
        setContentView(ui)
    }

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun activated(): Boolean = prefs.getLong("activated", 0L) > 0L

    private fun expired(): Boolean =
        activated() && System.currentTimeMillis() - prefs.getLong("activated", 0L) >= 3L * 24 * 60 * 60 * 1000

    private fun count(): Int {
        if (prefs.getString("day", "") != today()) return 0
        return prefs.getInt("count", 0)
    }

    private fun activateKey(value: String) {
        if (value.trim() != "PREMIUM-938448") {
            Toast.makeText(this, "Key không hợp lệ.", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putLong("activated", System.currentTimeMillis()).putString("day", today()).putInt("count", 0).apply()
        ui.page = 1
        ui.invalidate()
    }

    private fun create() {
        if (!activated()) {
            Toast.makeText(this, "Hãy nhập key chính thống trước.", Toast.LENGTH_SHORT).show()
            ui.page = 0; ui.invalidate(); return
        }
        if (expired()) {
            prefs.edit().clear().apply()
            Toast.makeText(this, "Key đã hết hạn sau 3 ngày.", Toast.LENGTH_SHORT).show()
            ui.page = 0; ui.invalidate(); return
        }
        if (count() >= 5) {
            ui.page = 5; ui.invalidate(); return
        }

        val request = ui.requestText.trim()
        if (request.isEmpty()) {
            Toast.makeText(this, "Hãy nhập yêu cầu muốn tạo file.", Toast.LENGTH_SHORT).show()
            return
        }

        prefs.edit().putString("day", today()).putInt("count", count() + 1).apply()
        ui.page = 2
        ui.progress = 0
        ui.invalidate()

        // Mock 1–2 minute creator flow. The app remains usable and visibly progresses.
        object : CountDownTimer(7000, 100) {
            override fun onTick(ms: Long) {
                ui.progress = ((7000 - ms) * 100 / 7000).toInt()
                ui.invalidate()
            }
            override fun onFinish() {
                ui.progress = 100
                ui.invalidate()
                Handler(Looper.getMainLooper()).postDelayed({
                    val name = ui.fileName.ifBlank { "AimCreator" }
                    val ext = ui.extension.ifBlank { ".lua" }.let { if (it.startsWith(".")) it else ".$it" }
                    pendingContent = """
                        // FILE AIM CREATOR
                        // Script: ${ui.script}
                        // Created: ${Date()}
                        //
                        // USER REQUEST:
                        $request
                    """.trimIndent()
                    ui.generatedName = name + ext
                    ui.page = 3
                    ui.invalidate()
                }, 500)
            }
        }.start()
    }

    private fun download() {
        saveFile.launch(ui.generatedName.ifBlank { "FileAimCreator.txt" })
    }

    inner class CreatorView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val logo = BitmapFactory.decodeResource(resources, R.drawable.file_aim_logo)
        var page = if (activated()) 1 else 0
        var progress = 0
        var sourceName = "Chưa chọn file"
        var generatedName = ""
        var fileName = ""
        var extension = ".lua"
        var script = "Script_Aim_Bot.lua"
        var requestText = ""
        var password = ""

        private val fields = mutableListOf<RectF>()
        private var rainbow = 0f

        init {
            setBackgroundColor(Color.rgb(5, 8, 18))
            isFocusable = true
        }

        private fun round(c: Canvas, r: RectF, fill: Int, stroke: Int? = null, sw: Float = 1f, radius: Float = 14f) {
            p.style = Paint.Style.FILL; p.color = fill
            c.drawRoundRect(r, radius, radius, p)
            if (stroke != null) {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = stroke
                c.drawRoundRect(r, radius, radius, p)
            }
            p.style = Paint.Style.FILL
        }

        private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean=false) {
            p.color = color; p.textSize = size; p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.style = Paint.Style.FILL
            c.drawText(s, x, y, p)
        }

        private fun center(c: Canvas, s: String, cx: Float, y: Float, size: Float, color: Int, bold: Boolean=false) {
            p.textSize=size; p.typeface=if(bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            text(c,s,cx-p.measureText(s)/2f,y,size,color,bold)
        }

        private fun rainbowColor(t: Float): Int {
            val h = ((t % 360f) + 360f) % 360f
            return Color.HSVToColor(floatArrayOf(h, .82f, 1f))
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            rainbow += 1.4f
            drawTop(c)
            when(page) {
                0 -> drawKey(c)
                1 -> drawHome(c)
                2 -> drawCreator(c)
                3 -> drawSuccess(c)
                4 -> drawInput(c)
                5 -> drawLimit(c)
            }
            postInvalidateDelayed(50)
        }

        private fun drawTop(c: Canvas) {
            val w=width.toFloat()
            if (page==0) {
                val d=RectF(w/2-70,18f,w/2+70,158f)
                c.drawBitmap(logo,null,d,p)
                center(c,"File Aim Creator",w/2,205f,24f,Color.WHITE,true)
                center(c,"Tạo File • Code • Script Theo Yêu Cầu",w/2,230f,13f,rainbowColor(rainbow),true)
            } else {
                c.drawBitmap(logo,null,RectF(18f,14f,86f,82f),p)
                text(c,"FILE AIM",98f,42f,21f,Color.WHITE,true)
                text(c,"CREATOR",98f,65f,16f,Color.CYAN,true)
                text(c,"♛",w-44f,52f,22f,rainbowColor(rainbow),true)
            }
        }

        private fun drawKey(c: Canvas) {
            val w=width.toFloat()
            center(c,"Nhập Key Chính Thống",w/2,285f,22f,Color.WHITE,true)
            round(c,RectF(28f,315f,w-28f,368f),Color.rgb(9,18,35),Color.rgb(0,170,255),2f)
            text(c,"🔑",45f,349f,18f,Color.WHITE)
            text(c,"${if (uiKey()) uiKey() else ""}",80f,350f,16f,Color.WHITE)
            button(c,RectF(28f,382f,w-28f,438f),"🔐  Xác Nhận Key",rainbowColor(rainbow))
            round(c,RectF(28f,460f,w-28f,555f),Color.rgb(7,30,31),Color.rgb(0,255,170),2f)
            text(c,"✓",45f,500f,25f,Color.rgb(0,255,170),true)
            text(c,"Key hợp lệ!",80f,493f,17f,Color.rgb(0,255,170),true)
            text(c,"Thời hạn: 3 ngày",80f,518f,13f,Color.LTGRAY)
            text(c,"Sau 3 ngày key sẽ reset và tạo key mới.",80f,540f,12f,Color.LTGRAY)
            center(c,"Chỉ được sử dụng 1 key chính thức.",w/2,595f,12f,Color.rgb(125,160,200))
        }

        private fun uiKey(): String = prefs.getString("enteredKey","") ?: ""

        private fun drawHome(c: Canvas) {
            val w=width.toFloat()
            round(c,RectF(18f,95f,w-18f,153f),Color.rgb(7,23,40),Color.rgb(0,200,255),1.5f)
            text(c,"●  Key: PREMIUM-938448",30f,121f,14f,Color.WHITE,true)
            text(c,"Đang hoạt động",30f,142f,11f,Color.rgb(50,255,160))
            text(c,"Còn lại: 3 ngày",w-120f,142f,11f,Color.CYAN)

            round(c,RectF(18f,165f,w/2-6f,218f),Color.rgb(10,18,35),Color.rgb(0,180,255))
            round(c,RectF(w/2+6f,165f,w-18f,218f),Color.rgb(10,18,35),Color.rgb(0,180,255))
            text(c,"↧  Lượt tạo hôm nay",32f,189f,11f,Color.LTGRAY)
            text(c,"${count()}/5",32f,209f,17f,Color.WHITE,true)
            text(c,"▣  Giới hạn mỗi ngày",w/2+20f,189f,11f,Color.LTGRAY)
            text(c,"5 lượt",w/2+20f,209f,17f,Color.WHITE,true)

            val labels=arrayOf("1. Nhập tên file","2. Nhập mật khẩu file","3. Chọn kịch bản","4. Chọn đuôi file","5. Chọn file","6. Creator File","7. Nhập yêu cầu")
            val colors=intArrayOf(
                Color.rgb(0,130,255),Color.rgb(140,50,255),Color.rgb(210,40,220),
                Color.rgb(255,80,45),Color.rgb(255,165,20),Color.rgb(20,210,110),Color.rgb(0,185,255)
            )
            var y=232f
            labels.forEachIndexed { i,s ->
                round(c,RectF(18f,y,w-18f,y+48f),colors[i],null,1f,12f)
                text(c,if(i==5)"🤖" else "›",30f,y+31f,20f,Color.WHITE,true)
                text(c,s,55f,y+30f,14f,Color.WHITE,true)
                text(c,"›",w-38f,y+31f,22f,Color.WHITE,true)
                y+=56f
            }
            text(c,"⌂",45f,y+45f,22f,Color.WHITE)
            text(c,"◷",w/2-15f,y+45f,22f,Color.LTGRAY)
            text(c,"⚙",w-60f,y+45f,22f,Color.LTGRAY)
        }

        private fun drawInput(c: Canvas) {
            val w=width.toFloat()
            text(c,"‹",20f,118f,35f,Color.CYAN,true)
            text(c,"Nhập yêu cầu tạo file",58f,110f,19f,Color.WHITE,true)
            round(c,RectF(22f,140f,w-22f,300f),Color.rgb(7,16,30),Color.rgb(0,180,255),1.5f)
            text(c,if(requestText.isEmpty())"Ví dụ: mô tả file bạn muốn tạo..." else requestText.take(65),36f,174f,14f,Color.LTGRAY)
            text(c,"${requestText.length}/500",w-100f,282f,11f,Color.GRAY)
            button(c,RectF(22f,320f,w-22f,375f),"⚡  Gửi yêu cầu",rainbowColor(rainbow))
            round(c,RectF(22f,395f,w-22f,505f),Color.rgb(8,18,33),Color.rgb(35,70,110))
            text(c,"Lưu ý:",38f,423f,14f,Color.WHITE,true)
            text(c,"• Mỗi ngày tối đa 5 lượt tạo file.",38f,447f,12f,Color.LTGRAY)
            text(c,"• Bot xử lý theo yêu cầu.",38f,468f,12f,Color.LTGRAY)
            text(c,"• Thời gian mô phỏng: 1–2 phút.",38f,489f,12f,Color.LTGRAY)
        }

        private fun drawCreator(c: Canvas) {
            val w=width.toFloat()
            center(c,"Creator Bot đang xử lý",w/2,130f,21f,Color.WHITE,true)
            c.drawBitmap(logo,null,RectF(w/2-70,155f,w/2+70,295f),p)
            center(c,"Đang tạo file theo yêu cầu của bạn...",w/2,330f,14f,Color.WHITE)
            center(c,"Vui lòng chờ khoảng 1 - 2 phút",w/2,353f,12f,Color.LTGRAY)
            p.style=Paint.Style.STROKE;p.strokeWidth=10f;p.color=Color.rgb(18,40,65)
            c.drawCircle(w/2,430f,55f,p)
            p.color=rainbowColor(rainbow)
            val rect=RectF(w/2-55,375f,w/2+55,485f)
            c.drawArc(rect,-90f,progress*3.6f,false,p);p.style=Paint.Style.FILL
            center(c,"$progress%",w/2,438f,23f,Color.WHITE,true)
            text(c,"✓  Phân tích yêu cầu",55f,525f,13f,Color.rgb(0,255,160))
            text(c,"✓  Tạo code / script",55f,552f,13f,Color.rgb(0,255,160))
            text(c,"✓  Đóng gói file",55f,579f,13f,Color.rgb(0,255,160))
            text(c,"◌  Đang hoàn thiện...",55f,606f,13f,rainbowColor(rainbow),true)
        }

        private fun drawSuccess(c: Canvas) {
            val w=width.toFloat()
            center(c,"Tạo file thành công!",w/2,122f,21f,Color.WHITE,true)
            center(c,"✓",w/2,205f,60f,Color.rgb(0,255,150),true)
            round(c,RectF(24f,240f,w-24f,360f),Color.rgb(7,18,32),Color.rgb(0,180,255),1.5f)
            text(c,"▣",42f,292f,35f,Color.CYAN)
            text(c,generatedName,92f,280f,16f,Color.WHITE,true)
            text(c,"Dung lượng: 2.4 MB",92f,307f,12f,Color.LTGRAY)
            text(c,"Mật khẩu: đã nhập",92f,330f,12f,Color.LTGRAY)
            button(c,RectF(24f,382f,w-24f,438f),"⬇  Tải file về",Color.rgb(0,220,135))
            button(c,RectF(24f,450f,w-24f,506f),"▣  Tạo file khác",rainbowColor(rainbow))
            round(c,RectF(24f,520f,w-24f,572f),Color.rgb(8,20,36),Color.rgb(0,170,255),1.5f)
            center(c,"‹  Quay về menu",w/2,553f,14f,Color.WHITE,true)
        }

        private fun drawLimit(c: Canvas) {
            val w=width.toFloat()
            center(c,"⚠",w/2,180f,54f,Color.rgb(255,80,110),true)
            center(c,"Đã đạt giới hạn hôm nay!",w/2,240f,21f,Color.WHITE,true)
            center(c,"Bạn đã tạo tối đa 5 file trong ngày.",w/2,275f,13f,Color.LTGRAY)
            center(c,"Vui lòng quay lại vào ngày mai.",w/2,298f,13f,Color.LTGRAY)
            button(c,RectF(25f,340f,w-25f,395f),"‹  Quay về menu",Color.rgb(15,75,120))
        }

        private fun button(c:Canvas,r:RectF,label:String,color:Int){
            round(c,r,color,null,1f,13f)
            center(c,label,r.centerX(),r.centerY()+6f,15f,Color.WHITE,true)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action != MotionEvent.ACTION_UP) return true
            val x=e.x; val y=e.y

            if (page==0) {
                if (y>310 && y<375) {
                    val input=EditText(this@MainActivity)
                    input.setText(uiKey())
                    input.hint="PREMIUM-938448"
                    val box=LinearLayout(this@MainActivity)
                    box.setPadding(35,0,35,0); box.addView(input)
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Nhập Key Chính Thống")
                        .setView(box)
                        .setPositiveButton("Xác nhận"){_,_->
                            prefs.edit().putString("enteredKey",input.text.toString()).apply()
                            activateKey(input.text.toString())
                        }.setNegativeButton("Hủy",null).show()
                }
                return true
            }

            if (page==1) {
                // Menu rows
                if (y in 232f..280f) editTextDialog("Nhập tên file", fileName) { fileName=it }
                else if (y in 288f..336f) editTextDialog("Mật khẩu file", password, true) { password=it }
                else if (y in 344f..392f) chooseScript()
                else if (y in 400f..448f) editExtension()
                else if (y in 456f..504f) openFile.launch(arrayOf("*/*"))
                else if (y in 512f..560f) create()
                else if (y in 568f..616f) { page=4; invalidate() }
            } else if (page==4) {
                if (y>300 && y<390) {
                    editTextDialog("Nhập yêu cầu muốn tạo file", requestText) { requestText=it }
                }
            } else if (page==3) {
                if (y in 382f..438f) download()
                else if (y in 450f..506f) { page=1; invalidate() }
                else if (y in 520f..590f) { page=1; invalidate() }
            } else if (page==5) {
                if (y in 330f..420f) { page=1; invalidate() }
            }
            return true
        }

        private fun editTextDialog(title:String, old:String, passwordMode:Boolean=false, done:(String)->Unit) {
            val e=EditText(this@MainActivity);e.setText(old);e.setSingleLine(false)
            if(passwordMode)e.inputType=0x81
            AlertDialog.Builder(this@MainActivity).setTitle(title).setView(e)
                .setPositiveButton("Lưu"){_,_->done(e.text.toString());invalidate()}
                .setNegativeButton("Hủy",null).show()
        }

        private fun chooseScript(){
            val a=arrayOf("Script_Aim_Bot.lua","JavaScript","Python","HTML","JSON")
            AlertDialog.Builder(this@MainActivity).setTitle("Chọn kịch bản").setItems(a){_,i->script=a[i];invalidate()}.show()
        }

        private fun editExtension(){
            editTextDialog("Chọn đuôi file",extension){extension=it.ifBlank{".lua"};invalidate()}
        }
    }
}
