# File Aim Creator — Mockup-matched Android app

Bản Android source được dựng theo mockup: logo, nền tối neon, thanh 7 màu, màn hình key, menu 7 mục, creator bot, màn hình thành công và giới hạn 5 lượt/ngày.

### Key
`PREMIUM-938448`

### Build trên GitHub
Push toàn bộ thư mục lên GitHub, vào **Actions → Build File Aim Creator APK → Run workflow**. APK debug nằm trong artifact `FileAimCreator-debug`.

### Ghi chú
- Thời gian creator được mô phỏng ngắn trong bản demo để test giao diện.
- Key 3 ngày và giới hạn 5 lượt/ngày được lưu cục bộ trên thiết bị.
- Creator hiện tạo file văn bản chứa yêu cầu của người dùng; đây là template/local creator, không phải dịch vụ AI online.